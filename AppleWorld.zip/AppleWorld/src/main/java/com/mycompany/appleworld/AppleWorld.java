package com.mycompany.appleworld;


import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class AppleWorld {
    public static void main(String[] args) {
        new LoginScreen();
    }

    static class UserProxy {
        private static Map<String, User> users = new HashMap<>();
        private static User currentUser;

        public static boolean login(String username, String password) {
            User user = users.get(username);
            if (user != null && user.password.equals(password)) {
                currentUser = user;
                return true;
            }
            return false;
        }

        public static boolean register(String username, String email, String password) {
            if (!users.containsKey(username)) {
                users.put(username, new User(username, email, password));
                return true;
            }
            return false;
        }
    }

    static class User {
        String username;
        String email;
        String password;

        User(String username, String email, String password) {
            this.username = username;
            this.email = email;
            this.password = password;
        }
    }

    static class LoginScreen extends JFrame {
        JTextField usernameField, emailField;
        JPasswordField passwordField;
        JButton loginButton, registerButton;

        LoginScreen() {
            setTitle("Apple World - Login/Register");
            setSize(300, 200);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);

            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

            usernameField = new JTextField(15);
            emailField = new JTextField(15);
            passwordField = new JPasswordField(15);

            loginButton = new JButton("Login");
            registerButton = new JButton("Register");

            panel.add(new JLabel("Username:"));
            panel.add(usernameField);
            panel.add(new JLabel("Email:"));
            panel.add(emailField);
            panel.add(new JLabel("Password:"));
            panel.add(passwordField);
            panel.add(loginButton);
            panel.add(registerButton);

            loginButton.addActionListener(new LoginAction());
            registerButton.addActionListener(new RegisterAction());

            add(panel);
            setVisible(true);
        }

        class LoginAction implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (UserProxy.login(username, password)) {
                    dispose();
                    new ProductScreen();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password");
                }
            }
        }

        class RegisterAction implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());

                if (UserProxy.register(username, email, password)) {
                    JOptionPane.showMessageDialog(null, "Registration successful! Please login.");
                } else {
                    JOptionPane.showMessageDialog(null, "Username already exists!");
                }
            }
        }
    }
}

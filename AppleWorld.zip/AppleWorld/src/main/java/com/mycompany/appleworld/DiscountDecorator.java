/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appleworld;

/**
 *
 * @author HP
 */
public class DiscountDecorator extends ProductDecorator {
     private double discountPercentage; 
     
     public DiscountDecorator(ProductComponent decoratedProduct, double discountPercentage) {
        super(decoratedProduct);
        this.discountPercentage = discountPercentage;
    }

    @Override
    public double getPrice() {
        return decoratedProduct.getPrice() * (1 - discountPercentage / 100);
    }

    @Override
    public String getName() {
        return decoratedProduct.getName() + " (Discount: " + discountPercentage + "%)";
    }
}


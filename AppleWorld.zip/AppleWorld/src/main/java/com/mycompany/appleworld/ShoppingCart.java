/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appleworld;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HP
 */
public class ShoppingCart {
   private static ShoppingCart instance;
    private List<ProductComponent> products;
    private List<CartObserver> observers;

    private ShoppingCart() {
        products = new ArrayList<>();
        observers = new ArrayList<>();
    }

    public static synchronized ShoppingCart getInstance() {
        if (instance == null) {
            instance = new ShoppingCart();
        }
        return instance;
    }

    public void addProduct(ProductComponent product) {
        products.add(product);
        notifyObservers();
    }

    public List<ProductComponent> getProducts() {
        return new ArrayList<>(products);
    }

    public double getTotalPrice() {
        double total = 0;
        for (ProductComponent product : products) {
            total += product.getPrice();
        }
        return total;
    }

    public void addObserver(CartObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(CartObserver observer) {
        observers.remove(observer);
    }

    private void notifyObservers() {
        double total = getTotalPrice();
        for (CartObserver observer : observers) {
            observer.update(products, total);
        }
    }
}

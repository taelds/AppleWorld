package com.mycompany.appleworld;


import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class CheckoutScreen extends JFrame {
    JTextField addressField, countryField, cityField, zipField, nameField;

    CheckoutScreen() {
        setTitle("Apple World - Checkout");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        addressField = new JTextField(15);
        countryField = new JTextField(15);
        cityField = new JTextField(15);
        zipField = new JTextField(15);
        nameField = new JTextField(15);

        panel.add(new JLabel("Full Address:"));
        panel.add(addressField);
        panel.add(new JLabel("Country:"));
        panel.add(countryField);
        panel.add(new JLabel("City:"));
        panel.add(cityField);
        panel.add(new JLabel("Zip Code:"));
        panel.add(zipField);
        panel.add(new JLabel("Full Name:"));
        panel.add(nameField);

        JButton submitButton = new JButton("Submit Order");
        submitButton.addActionListener(new SubmitOrderAction());
        panel.add(submitButton);

        add(panel);
        setVisible(true);
    }

    class SubmitOrderAction implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String address = addressField.getText();
            String country = countryField.getText();
            String city = cityField.getText();
            String zip = zipField.getText();
            String name = nameField.getText();

            if (address.isEmpty() || country.isEmpty() || city.isEmpty() || zip.isEmpty() || name.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields must be filled out");
            } else {
                JOptionPane.showMessageDialog(null, "Order submitted successfully!");
                System.exit(0);
            }
        }
    }
}

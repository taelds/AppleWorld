package com.mycompany.appleworld;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

class ProductScreen extends JFrame{
        ProductScreen() {
        setTitle("Apple World - Products");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] productNames = {"iPhone", "MacBook", "iPad", "Apple Watch"};
        double[] productPrices = {999.99, 1299.99, 799.99, 399.99};
        String[] productDescriptions = {
            "The latest iPhone model.",
            "High-performance MacBook for professionals.",
            "Versatile iPad for all your needs.",
            "Smartwatch with health tracking features."
        };
        String[] productImages = {
            "/images/iphone.jpg",
            "/images/macbook.jpg",
            "/images/ipad.jpg",
            "/images/apple_watch.jpg"
        };

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        for (int i = 0; i < productNames.length; i++) {
            JButton productButton = new JButton(productNames[i] + " - $" + productPrices[i]);
            int index = i;
            productButton.addActionListener(e -> showProductDetails(productNames[index], productPrices[index], productDescriptions[index], productImages[index]));
            panel.add(productButton);
        }

        JButton viewCartButton = new JButton("View Cart");
        viewCartButton.addActionListener(e -> new CartScreen());
        panel.add(viewCartButton);

        add(panel);
        setVisible(true);
    }

    private void showProductDetails(String name, double price, String description, String imagePath) {
        JFrame detailsFrame = new JFrame(name);
        detailsFrame.setSize(300, 400);
        detailsFrame.setLocationRelativeTo(null);

        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));

        JLabel nameLabel = new JLabel(name);
        JLabel priceLabel = new JLabel("Price: $" + price);
        JLabel descriptionLabel = new JLabel("<html><body style='width: 200px'>" + description + "</body></html>");

        // Load and resize the product image
        JLabel imageLabel = new JLabel();
        ImageIcon originalIcon = new ImageIcon(getClass().getResource(imagePath));
        Image originalImage = originalIcon.getImage();
        Image resizedImage = originalImage.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
        imageLabel.setIcon(resizedIcon);

        JButton addToCartButton = new JButton("Add to Cart");
        addToCartButton.addActionListener(e -> {
            ProductComponent product = new Product(name, price);
            product = new DiscountDecorator(product, 10); // Apply a 10% discount
            product = new FreeShippingDecorator(product); // Add free shipping
            ShoppingCart.getInstance().addProduct(product);
            JOptionPane.showMessageDialog(null, name + " added to cart");
        });

        detailsPanel.add(nameLabel);
        detailsPanel.add(priceLabel);
        detailsPanel.add(descriptionLabel);
        detailsPanel.add(imageLabel); // Add the image label to the panel
        detailsPanel.add(addToCartButton);

        detailsFrame.add(detailsPanel);
        detailsFrame.setVisible(true);
    }

    static class Product implements ProductComponent {
        String name;
        double price;

        Product(String name, double price) {
            this.name = name;
            this.price = price;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public double getPrice() {
            return price;
        }
    }
}

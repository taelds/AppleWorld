

package com.mycompany.appleworld;
import javax.swing.*;
import java.util.List;

class CartScreen extends JFrame implements CartObserver{
private JPanel panel;

    CartScreen() {
        setTitle("Apple World - Cart");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        ShoppingCart.getInstance().addObserver(this); // Register as an observer

        updateCart();

        JButton checkoutButton = new JButton("Checkout");
        checkoutButton.addActionListener(e -> new CheckoutScreen());
        panel.add(checkoutButton);

        add(panel);
        setVisible(true);
    }

    private void updateCart() {
        panel.removeAll();

        List<ProductComponent> cart = ShoppingCart.getInstance().getProducts();
        double total = ShoppingCart.getInstance().getTotalPrice();

        for (ProductComponent product : cart) {
            panel.add(new JLabel(product.getName() + " - $" + product.getPrice()));
        }

        panel.add(new JLabel("Total: $" + total));

        panel.revalidate();
        panel.repaint();
    }

    @Override
    public void update(List<ProductComponent> products, double total) {
        updateCart();
    }
}
